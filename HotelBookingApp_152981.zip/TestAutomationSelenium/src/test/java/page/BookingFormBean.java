package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BookingFormBean {

	WebDriver driver;


	@FindBy(name="firstName",how=How.NAME)
	private WebElement firstName;
	@FindBy(name="lastName",how=How.NAME)
	private WebElement lastName;
	@FindBy(name="address")
	private WebElement address;
	@FindBy(name="city")
	private WebElement city;
	@FindBy(name="state")
	private WebElement state;
	@FindBy(name="Email")
	private WebElement Email;
	@FindBy(name="persons")
	private WebElement persons;
	@FindBy(name="rooms")
	private WebElement rooms;
	@FindBy(name="mobilenumber")
	private WebElement mobilenumber;
	public void navigateTo_NextPage() {
		
		// TODO Auto-generated method stub
		
	}
	public void navigateTo_NextPage(String capgemini, String capg1234) {
		// TODO Auto-generated method stub
		
	}
	
	
}







