package loginForm;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.BookingFormBean;


public class Stepdef {
	private WebDriver driver;
	private WebElement element;
	private BookingFormBean bookingForm;
	
	@Before
	public void setUp() {
	
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dhanap\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@Given("^Open login form page$")
	public void open_login_form_page() throws Throwable {
		driver.get("http://localhost:8084/TestAutomationSelenium/");
	}

	@When("^login form are validated$")
	public void login_form_are_validated() throws Throwable {
		bookingForm.navigateTo_NextPage ("capgemini", "capg1234");
		
	}

	@Then("^it should move to the next page\\.$")
	public void it_should_move_to_the_next_page() throws Throwable {
		String url= driver.getCurrentUrl();
		   assertTrue(url.equals("http://localhost:8084/TestAutomationSelenium/validateForm"));
	}
}