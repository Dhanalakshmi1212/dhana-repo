package bookingForm;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.BookingFormBean;

public class Stepdef {
	
	private WebDriver driver;
	private WebElement element;
	private BookingFormBean bookingForm;
	
	@Before
	public void setUp() {
	
		System.setProperty("webdriver.chrome.driver", 
				"D:\\Users\\dhanap\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	@Given("^Open booking form page$")
	public void open_booking_form_page() throws Throwable {
		driver.get("http://localhost:8084/TestAutomationSelenium/");
	}

	@When("^booking form are validated$")
	public void booking_form_are_validated() throws Throwable {
		/*bookingForm.navigateTo_NextPage ("Tom", "Cat", "tom@gmail.com", "9008768977"
				"N0.34 2nd cross Street, "Chennai", "Tamilnadu", "2", "1", "Tonny", );
*/	}

	@Then("^it should navigate to success page$")
	public void it_should_navigate_to_success_page() throws Throwable {
		 String url= driver.getCurrentUrl();
		   assertTrue(url.equals("http://localhost:8084/TestAutomationSelenium/validatechkEmpty"));
	}
	
}