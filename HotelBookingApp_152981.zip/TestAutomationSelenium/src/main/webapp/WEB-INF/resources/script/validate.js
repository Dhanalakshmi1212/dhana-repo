function validateForm() {
	var username=myform.userName.value;
	var userpwd=myform.userPwd.value;
	var flag=false;
	if(username==""||username==null){
		alert("Please enter FirstName");
	}
	else if(validname.test(firstname) == false)
	{
alert("Please enter a vaild Firstname");
	}
	else if(userPwd=="" || userPwd==null)
	{
	alert("Please enter LastName");
	}
else if(validname.test(userPwd) == false)
{
alert("Please enter a vaild userPwd");
}
else{
	flag=true;
}
	return flag;

	
}
function validatechkEmpty(){
	var firstname=frmReg.firstName.value;
	var lastName=frmReg.lastName.value;
	var address=frmReg.address.value;
	var city=frmReg.city.value;
	var state=frmReg.state.value;
	var gender=frmReg.gender.value;
	var course=frmReg.course.value;
	var mobilenum=frmReg.mobilenum.value;
	var validname=/^[A-Z][a-zA-Z]{2,}$/;
	var validmobileNo=/^\d{10}$/;
	var txtFN=frmReg.txtFN.value;
	var debit=frmReg.debit.value;
	var cvv=frmReg.cvv.value;
	var month=frmReg.month.value;
	var year=frmReg.year.value;
	var validname=/^[A-Z]{3,}$/;
	var validcardNo=/^\d{16}$/;
	var validcvvNo=/^\d{3}$/;
	var dateformat = /^(0?[1-9]|1[012])[\/]\d{2}$/;
	var flag=false;
	if(firstname==""||firstname==null){
		alert("Please enter FirstName");
	}
	else if(validname.test(firstname) == false)
	{
alert("Please enter a vaild Firstname");
	}
	else if(lastName=="" || lastName==null)
		{
		alert("Please enter LastName");
		}
	else if(validname.test(lastName) == false)
	{
alert("Please enter a vaild Lastname");
	}
	else if(address=="" || address==null)
	{
	alert("Please enter address");
	}
	else if(city=="" || city==null)
	{
	alert("Please enter city");
	}
	
	else if(state=="" || state==null)
	{
	alert("Please enter state");
	}
	else if(Email=="" || Email==null)
	{
	alert("Please enter Email");
	}
	
	else if(rooms=="" || rooms==null)
	{
	alert("Please enter rooms");
	}
	else if(mobilenumber=="" || mobilenumber==null)
	{
	alert("Please enter mobile number");
	}
	else if(validmobileNo.test(mobilenumber) == false)
	{
alert("Please enter a vaild mobile number");
	}
	

	else if(txtFN==""||txtFN==null){
		alert("Please enter Card holder name");
	}
	else if(validname.test(txtFN) == false)
			{
		alert("Please enter a vaild Card holder name");
			}
	else if(debit=="" || debit==null)
		{
		alert("Please enter card number");
		}
	else if(validcardNo.test(debit) == false)
	{
alert("Please enter a vaild card number");
	}
	else if(cvv=="" || cvv==null)
	{
	alert("Please enter cvv number");
	}
	else if(validcvvNo.test(cvv) == false)
	{
alert("Please enter a vaild cvv number");
	}
	else if(month=="" || month==null)
	{
	alert("Please enter expiry month");
	}
	else if(year=="" || year==null)
	{
	alert("Please enter expiry year");
	}
	
	/*else if(dateformat.test(exDate) == false)
	{
alert("Please enter a vaild date mm/yy");
	}*/
	else{
		flag=true;
	}
		return flag;
}

