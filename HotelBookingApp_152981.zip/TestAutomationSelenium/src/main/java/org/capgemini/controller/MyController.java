package org.capgemini.controller;

import org.springframework.web.bind.annotation.RequestMapping;

public class MyController {
	@RequestMapping("/")
	public String hotelbookingForm() {
		
		return "login";
		
	}
	@RequestMapping("/next")
	public String personalPage() {
		return "hotelbooking";
	}
	
	@RequestMapping("/next")
	public String successPage() {
		return "success";
	}
	
@RequestMapping("/pay")
public String makePayment() {
	return "redirect:/";
}
	}


