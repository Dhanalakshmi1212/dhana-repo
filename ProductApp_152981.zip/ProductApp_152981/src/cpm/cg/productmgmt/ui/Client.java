package cpm.cg.productmgmt.ui;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import cpm.cg.productmgmt.exception.ProductException;
import cpm.cg.productmgmt.service.IProductService;
import cpm.cg.productmgmt.service.ProductService;


public class Client {
	String category;
	int hike;
	
	Scanner scan=new Scanner(System.in);
	IProductService productService= new ProductService();

	public static void main(String[] args) {
            String option=null;
	Client c=new Client();
	
	while(true) {
		System.out.println("======Product Management System==========");
		System.out.println("1. Update Product Price");
		System.out.println("2. Display Product List");
		System.out.println("3. Exit");
		option=c.scan.nextLine();
		
		switch(option) {
		case "1":
			c.updateProducts();
			break;
		case "2":
		c.displayList();
			break;
		case "3":
			System.exit(0);
		default:
			System.err.println("Invalid option choose from 1 to 3");
			System.out.println(" ");
			break;
					}
				}
			}

	private void updateProducts() {
		try { 
		
		System.out.println("Enter Product Category");
		category=scan.nextLine();
		System.out.println("Enter the hike in prodect category");
		hike=Integer.parseInt(scan.nextLine());
		int ret=productService.updateProducts(category,hike);
		
		if(ret==1) {
			System.out.println("Successfully hiked prices for"+category+"by"+hike);
		}
		}catch (ProductException e) {
			System.out.println("Error occured:"+e.getMessage());
	}
	}
private void displayList() {
	try {
		Map<String,Integer> productDetails=productService.getProductDetails();
		Set set=productDetails.entrySet();
		set.stream().forEach(System.out::println);
		} catch (ProductException e) {
		System.err.println("An error occured:"+e.getMessage());
		}
			
	}
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


