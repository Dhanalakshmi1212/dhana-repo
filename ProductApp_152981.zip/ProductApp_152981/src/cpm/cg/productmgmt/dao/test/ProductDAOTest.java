package cpm.cg.productmgmt.dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import cpm.cg.productmgmt.dao.IProductDAO;
import cpm.cg.productmgmt.dao.ProductDAO;
import cpm.cg.productmgmt.exception.ProductException;

public class ProductDAOTest {
IProductDAO p=new ProductDAO();
	@Test 
	public void testUpdateProducts() throws ProductException {
		try {
			 p.updateProducts("paste", 6);
		}catch (Exception e) {
			throw new ProductException();
			}
	}

	@Test
	public void testGetProductDetails() {
		try {
			assertNotNull(p.getProductDetails());
	}catch (ProductException e) {
		e.printStackTrace();
	}
	}
}

