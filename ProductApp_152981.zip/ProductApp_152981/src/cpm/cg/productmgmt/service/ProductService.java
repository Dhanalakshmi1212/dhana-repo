package cpm.cg.productmgmt.service;

import java.util.Map;

import cpm.cg.productmgmt.dao.IProductDAO;
import cpm.cg.productmgmt.dao.ProductDAO;
import cpm.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	IProductDAO productDAO=new ProductDAO();

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
	
		return productDAO.updateProducts(Category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return productDAO.getProductDetails();
	}

}
